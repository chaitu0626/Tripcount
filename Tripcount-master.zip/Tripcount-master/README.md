# Tripcount
an android app for managing group-trips and day to day expenses

Tripcount is divided into two modules

### 1. Trip Expenses 
In this option we can no of friends while on group trips and you just need to update the money paid by particular friend and the app will automatically calculate who owes how much money.

### 2. Day2Day Expenses
In this option you can add friends and amount paid or taken by them so that you can keep track of all your friends separately.

## Development
This project is developed in Android Stdio 2.0

## Project Contributors
[Mandeep Singh](https://github.com/msdeep14) ->mandeepsinghshekhawat95@gmail.com

[Pawan Sheoran](https://github.com/pawan231) ->psheoran231@gmail.com
